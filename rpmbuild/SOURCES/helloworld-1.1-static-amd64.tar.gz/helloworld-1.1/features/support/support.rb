require 'capybara/cucumber'

Capybara.default_driver = :selenium